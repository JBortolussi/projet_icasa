package follow.me.binary;

import java.util.Set;

public interface BinaryLightsInterface {
	public void turnOnBinaryLightIn(String location, int maxNumber);
	public void turnOffBinaryLightIn(String location);
	public void newRoom(String name, int numberOfLightToBeOn);
	public void updateRoom(String name, int numberOfLightToBeOn);
	public int  getRoom(String name);
	public Set<String> getOccupiedRomms();
	public void removeRoom(String name);
	
//	public int getNumberOfBinaryLightIn(String location);
}
