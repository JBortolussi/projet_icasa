package follow.me.binary;

import fr.liglab.adele.icasa.device.DeviceListener;
import fr.liglab.adele.icasa.device.GenericDevice;
import fr.liglab.adele.icasa.device.light.BinaryLight;
import fr.liglab.adele.icasa.device.presence.PresenceSensor;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BinaryLightHandlerImpl implements BinaryLightsInterface, DeviceListener {
	
	/**
     * The name of the LOCATION property
     */
    public static final String LOCATION_PROPERTY_NAME = "Location";
     
    /**
     * The name of the location for unknown value
     */
    public static final String LOCATION_UNKNOWN = "unknown";

	/** Field for binaryLights dependency */
	private BinaryLight[] binaryLights;
	
	// -------------------------- Parameters ----------------------------
	private Hashtable<String, Integer>  occupiedRooms;

	// -------------------------- Life cycle ----------------------------
	/** Bind Method for binaryLights dependency */
	public void bindBinaryLights(BinaryLight binaryLight, Map properties) {
		System.out.println("bind binary light " + binaryLight.getSerialNumber());
		binaryLight.addListener(this);
	}

	/** Unbind Method for binaryLights dependency */
	public void unbindBinaryLights(BinaryLight binaryLight, Map properties) {
		System.out.println("unbind binary light " + binaryLight.getSerialNumber());
		binaryLight.removeListener(this);
	}
	
	/** Component Lifecycle Method */
	public void stop() {
		System.out.println("BinaryLightHandler is stopping...");
		for (BinaryLight light : binaryLights){
			light.removeListener(this);
		}
	}

	/** Component Lifecycle Method */
	public void start() {
		occupiedRooms = new Hashtable<String, Integer>();
		System.out.println("BinaryLightHandler is starting...");
	}
	
	// -------------------------- Utility -----------------------------------------
	/** retrieve binary light from a room */
	private synchronized List<BinaryLight> getBinaryLightFromLocation(
		    String location) {
		  List<BinaryLight> binaryLightsLocation = new ArrayList<BinaryLight>();
		  for (BinaryLight binLight : binaryLights) {
		    if (binLight.getPropertyValue(LOCATION_PROPERTY_NAME).equals(
		        location)) {
		      binaryLightsLocation.add(binLight);
		    }
		  }
		  return binaryLightsLocation;
		}
	
	// -------------------------- BinaryLightsInterface ----------------------------
	@Override
	public void turnOnBinaryLightIn(String location, int maxNumber) {
		System.out.print("Updating light in " + location + ", max number : " + maxNumber);
		List<BinaryLight> lights = getBinaryLightFromLocation(location);
		int numberOfLightOn = 0; 
		for (BinaryLight light : lights){
			if (numberOfLightOn < maxNumber){
				light.turnOn();
				numberOfLightOn += 1;
			} else {
				light.turnOff();
			}
			
		}
	}

	@Override
	public void turnOffBinaryLightIn(String location) {
		List<BinaryLight> lights = getBinaryLightFromLocation(location);
		for (BinaryLight light : lights){
			light.turnOff();
		}
	}
	
	@Override
	public void newRoom(String name, int numberOfLightToBeOn){
		occupiedRooms.put(name, new Integer(numberOfLightToBeOn));
	}
	
	@Override
	public void updateRoom(String name, int numberOfLightToBeOn){
		occupiedRooms.replace(name, numberOfLightToBeOn);
	}
	
	@Override
	public int getRoom(String name){
		Integer maxNumber = occupiedRooms.get(name);
		if (maxNumber == null){
			return -1;
		} else {
			return maxNumber.intValue();
		}
	}
	
	@Override
	public void removeRoom(String name){
		occupiedRooms.remove(name);
	}
	
//	@Override
//	public int getNumberOfBinaryLightIn(String location){
//		return getBinaryLightFromLocation(location).size();
//	}
	
	@Override
	public Set<String> getOccupiedRomms(){
		return occupiedRooms.keySet();
	}
	
	// -------------------------- DeviceListener ------------------------------------
	@Override
	public void deviceAdded(GenericDevice arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deviceEvent(GenericDevice arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void devicePropertyAdded(GenericDevice arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void devicePropertyModified(GenericDevice device,
			String propertyName, Object oldValue, Object newValue) {

		//based on that assumption we can cast the generic device without checking via instanceof

		if (device instanceof BinaryLight) {
			BinaryLight changingLight = (BinaryLight) device;
			// check the change is related to presence sensing
			if (propertyName
					.equals(BinaryLight.LOCATION_PROPERTY_NAME)) {
				// get the location of the changing sensor:
				String lightLocation = (String) changingLight
						.getPropertyValue(LOCATION_PROPERTY_NAME);

				System.out.println("The light ("
						+ changingLight.getSerialNumber() + ") in the "
						+ lightLocation + " has moved");
				//System.out.println("old value : " + (String) oldValue);
				
				String oldLocation = (String) oldValue;
				
				// update new location
				int numberOfLightOn = 0;
				int maxlight = 0;
				List<BinaryLight> lights = null;
				if (occupiedRooms.containsKey(lightLocation)){
					maxlight = occupiedRooms.get(lightLocation);
					lights = getBinaryLightFromLocation(lightLocation);
					for (BinaryLight light : lights){
						if (light.getPowerStatus()){
							numberOfLightOn += 1;
						}
					}
					if ( numberOfLightOn > maxlight){
						changingLight.turnOff();
					} else if (numberOfLightOn < maxlight){
						changingLight.turnOn();
					}
					
				} else {
					changingLight.turnOff();
				}
				
				// update old location
				if (occupiedRooms.containsKey(oldLocation)){
					numberOfLightOn = 0;
					maxlight = occupiedRooms.get(oldLocation);
					lights = getBinaryLightFromLocation(oldLocation);
					for (BinaryLight light : lights){
						if (light.getPowerStatus()){
							numberOfLightOn += 1;
						}
					}
					for (BinaryLight light : lights){
						if (!light.getPowerStatus() && numberOfLightOn < maxlight){
							numberOfLightOn += 1;
							light.turnOn();
						}
					}
				}
			}
		}
	}


	@Override
	public void devicePropertyRemoved(GenericDevice arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deviceRemoved(GenericDevice arg0) {
		// TODO Auto-generated method stub
		
	}
}
