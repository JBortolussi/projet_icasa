package follow.me.manager;

public interface FollowMeAdministration {
	/**
     * Sets the illuminance preference. The manager will try to adjust the
     * illuminance in accordance with this goal.
     * 
     * @param illuminanceGoal
     *            the new illuminance preference
     */
    public void setIlluminancePreference(IlluminanceGoal illuminanceGoal);
 
    /**
     * Get the current illuminance preference.
     * 
     * @return the new illuminance preference
     */
    public IlluminanceGoal getIlluminancePreference();
    
    public void setUserPreference(String name, IlluminanceGoal goal);
}
