package follow.me.manager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import follow.me.configuration.FollowMeConfiguration;
import fr.liglab.adele.icasa.device.light.BinaryLight;
import fr.liglab.adele.icasa.location.LocatedDevice;
import fr.liglab.adele.icasa.location.Position;
import fr.liglab.adele.icasa.service.preferences.Preferences;
import fr.liglab.adele.icasa.service.location.PersonLocationService;
import fr.liglab.adele.icasa.simulator.Person;
import fr.liglab.adele.icasa.simulator.listener.PersonListener;
import java.util.Map;

public class FollowMeAdministrationImpl implements FollowMeAdministration {

	/** Field for followMeConfiguration dependency */
	private FollowMeConfiguration followMeConfiguration;
	/** Field for preference dependency */
	private Preferences preferences;
	/** Field for location dependency */
	private PersonLocationService locationService;

	// ------------------------------- Life cycle ----------------------------------
	/** Component Lifecycle Method */
	public void stop() {
	}

	/** Component Lifecycle Method */
	public void start() {
		// TODO: Add your implementation code here
	}

//	// --------------------------------- Utility ------------------------------------
//	private void updateRoom(String location) {
//		Set<String> persons = locationService.getPersonInZone(location);
//		if (persons.isEmpty()) {
//			followMeConfiguration.updateRoom(location, -1);
//		}
//		Iterator anIterator = persons.iterator();
//		int sum = 0;
//		String pref;
//		while (anIterator.hasNext()) {
//			String person = (String) anIterator.next();
//			pref = (String) preferences.getUserPropertyValue(person,
//					USER_PROP_ILLUMINANCE);
//			System.out.println("Updating " + location + " with preference of "
//					+ person + "(" + pref + ")");
//			switch (pref) {
//			case USER_PROP_ILLUMINANCE_VALUE_SOFT:
//				sum += 1;
//				break;
//			case USER_PROP_ILLUMINANCE_VALUE_MEDIUM:
//				sum += 2;
//				break;
//			case USER_PROP_ILLUMINANCE_VALUE_FULL:
//				sum += 3;
//				break;
//			default:
//				break;
//			}
//		}
//		followMeConfiguration.updateRoom(location, (int) sum / persons.size());
//	}

	// -------------------------- FollowMeAdministration ----------------------------
	@Override
	public void setIlluminancePreference(IlluminanceGoal illuminanceGoal) {
		followMeConfiguration.setMaximumNumberOfLightsToTurnOn(illuminanceGoal
				.getNumberOfLightsToTurnOn());
	}

	@Override
	public IlluminanceGoal getIlluminancePreference() {
		int goalInt = followMeConfiguration.getMaximumNumberOfLightsToTurnOn();
		IlluminanceGoal goal;
		switch (goalInt) {
		case 1:
			goal = IlluminanceGoal.SOFT;
			break;
		case 2:
			goal = IlluminanceGoal.MEDIUM;
			break;
		case 3:
			goal = IlluminanceGoal.FULL;
			break;
		default:
			goal = null;
			break;
		}
		return goal;
	}

	public void setUserPreference(String name, IlluminanceGoal goal) {
		String s_goal;
		switch (goal) {
		case SOFT:
			s_goal = FollowMeConfiguration.USER_PROP_ILLUMINANCE_VALUE_SOFT;
			break;
		case MEDIUM:
			s_goal = FollowMeConfiguration.USER_PROP_ILLUMINANCE_VALUE_MEDIUM;
			break;
		case FULL:
			s_goal = FollowMeConfiguration.USER_PROP_ILLUMINANCE_VALUE_FULL;
			break;
		default:
			s_goal = null;
		}
		if (s_goal != null) {
			preferences.setUserPropertyValue(name, FollowMeConfiguration.USER_PROP_ILLUMINANCE,
					s_goal);
			followMeConfiguration.changedProperty(name, null, null);
		}
	}
}
