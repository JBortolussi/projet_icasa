/**
 * 
 */
package follow.me.configuration;

/**
 * @author Utilisateur
 *
 */
public interface FollowMeConfiguration {
	/**
	 * User preferences for illuminance
	 **/
	public static final String USER_PROP_ILLUMINANCE = "illuminance";
	public static final String USER_PROP_ILLUMINANCE_VALUE_SOFT = "SOFT";
	public static final String USER_PROP_ILLUMINANCE_VALUE_MEDIUM = "MEDIUM";
	public static final String USER_PROP_ILLUMINANCE_VALUE_FULL = "FULL";
	
    /**
     * Gets the maximum number of lights to turn on each time an user is
     * entering a room.
     * 
     * @return the maximum number of lights to turn on
     */
    public int getMaximumNumberOfLightsToTurnOn();
 
    /**
     * Sets the maximum number of lights to turn on each time an user is
     * entering a room.
     * 
     * @param maximumNumberOfLightsToTurnOn
     *            the new maximum number of lights to turn on
     */
    public void setMaximumNumberOfLightsToTurnOn(int maximumNumberOfLightsToTurnOn);
    
    public void updateRoom(String location, int preferedNumberOfLight);
    public void changedProperty(String name, Object arg1, Object arg2);
}
