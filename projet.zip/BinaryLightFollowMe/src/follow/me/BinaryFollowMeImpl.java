package follow.me;

import fr.liglab.adele.icasa.device.DeviceListener;
import fr.liglab.adele.icasa.device.GenericDevice;
import fr.liglab.adele.icasa.device.presence.PresenceSensor;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.felix.ipojo.Nullable;
import org.apache.felix.ipojo.annotations.Requires;

import follow.me.binary.BinaryLightsInterface;
import follow.me.configuration.FollowMeConfiguration;
import fr.liglab.adele.icasa.service.location.PersonLocationService;
import fr.liglab.adele.icasa.service.preferences.PreferenceChangeListener;
import fr.liglab.adele.icasa.service.preferences.Preferences;
import fr.liglab.adele.icasa.service.scheduler.PeriodicRunnable;
import follow.me.dimmer.DimmerLightsInterface;

public class BinaryFollowMeImpl implements DeviceListener,
		FollowMeConfiguration, PeriodicRunnable {

	/**
	 * The name of the LOCATION property
	 */
	public static final String LOCATION_PROPERTY_NAME = "Location";

	/**
	 * The name of the location for unknown value
	 */
	public static final String LOCATION_UNKNOWN = "unknown";

	/** Field for presenceSensors dependency */
	private PresenceSensor[] presenceSensors;
	/** Field for binaryHandlers dependency */
	private BinaryLightsInterface[] binaryHandlers;
	/** Field for locationService dependency */
	private PersonLocationService locationService;

	/** Field for userPreferences dependency */
	private Preferences userPreferences;
	
	/** Field for dimmerHandlers dependency */
	private DimmerLightsInterface[] dimmerHandlers;

	// -------------------------- Parameters ----------------------------
	private int MaximumNumberOfLightsToTurnOn;

	// -------------------------- Life cycle ----------------------------
	/** Bind Method for presenceSensors dependency */
	public void bindPresenceSensors(PresenceSensor presenceSensor,
			Map properties) {
		presenceSensor.addListener(this);
		System.out.println("bind presence sensor "
				+ presenceSensor.getSerialNumber());
		// TODO: Add your implementation code here
	}

	/** Unbind Method for presenceSensors dependency */
	public void unbindPresenceSensors(PresenceSensor presenceSensor,
			Map properties) {
		presenceSensor.removeListener(this);
		System.out.println("unbind presence sensor "
				+ presenceSensor.getSerialNumber());
		// TODO: Add your implementation code here
	}
	
	/** Bind Method for dimmerHandlers dependency */
	public void bindDimmerHandlers(DimmerLightsInterface dimmerLightsInterface,
			Map properties) {
		// TODO: Add your implementation code here
	}

	/** Unbind Method for dimmerHandlers dependency */
	public void unbindDimmerHandlers(
			DimmerLightsInterface dimmerLightsInterface, Map properties) {
		// TODO: Add your implementation code here
	}

	/** Component Lifecycle Method */
	public void stop() {
		System.out.println("BinaryFollowMe is stopping...");
		for (PresenceSensor sensor : presenceSensors) {
			sensor.removeListener(this);
		}
	}

	/** Component Lifecycle Method */
	public void start() {
		System.out.println("BinaryFollowMe is starting...");
		MaximumNumberOfLightsToTurnOn = 2;
	}

	// ----------------------------- Utility --------------------------------
	private int computeMaxIn(String location){
		System.out.println("Updating lights in " + location + " with :");
		Set<String> persons = locationService.getPersonInZone(location);
		int preferedNumber;
		if (persons.isEmpty()) {
			System.out.println("	The room (" + location + ") is empty");
			preferedNumber = MaximumNumberOfLightsToTurnOn;
		} else {
			Iterator anIterator = persons.iterator();
			int sum = 0;
			String pref;
			while (anIterator.hasNext()) {
				String person = (String) anIterator.next();
				pref = (String) userPreferences.getUserPropertyValue(person,
						USER_PROP_ILLUMINANCE);
				if (pref == null) {
					System.out.println("	" + person + "has no preference -> "
							+ MaximumNumberOfLightsToTurnOn);
					sum += MaximumNumberOfLightsToTurnOn;
					continue;
				}
				System.out.println("	" + person + "preference is " + pref);
				switch (pref) {
				case USER_PROP_ILLUMINANCE_VALUE_SOFT:
					sum += 1;
					break;
				case USER_PROP_ILLUMINANCE_VALUE_MEDIUM:
					sum += 2;
					break;
				case USER_PROP_ILLUMINANCE_VALUE_FULL:
					sum += 3;
					break;
				default:
					break;
				}
				System.out.println("");
			}
			preferedNumber = (int) sum / persons.size();
			System.out.println("	preferedNumber -> " + preferedNumber
					+ " (computeMaxBinaryIn)");
			System.out.println("	sum -> " + sum);
			System.out.println("	person.size() -> " + persons.size());
		}
		preferedNumber = Math.min(MaximumNumberOfLightsToTurnOn, preferedNumber);
		
		return preferedNumber;
	}
	
	private int computeMaxBinaryIn(String location) {
		// Change here to modify power consumption
		// Change here to take dimmer light into account
//		System.out.println("Updating lights in " + location + " with :");
//		Set<String> persons = locationService.getPersonInZone(location);
//		int preferedNumber;
//		if (persons.isEmpty()) {
//			System.out.println("	The room (" + location + ") is empty");
//			preferedNumber = MaximumNumberOfLightsToTurnOn;
//		} else {
//			Iterator anIterator = persons.iterator();
//			int sum = 0;
//			String pref;
//			while (anIterator.hasNext()) {
//				String person = (String) anIterator.next();
//				pref = (String) userPreferences.getUserPropertyValue(person,
//						USER_PROP_ILLUMINANCE);
//				if (pref == null) {
//					System.out.println("	" + person + "has no preference -> "
//							+ MaximumNumberOfLightsToTurnOn);
//					sum += MaximumNumberOfLightsToTurnOn;
//					continue;
//				}
//				System.out.println("	" + person + "preference is " + pref);
//				switch (pref) {
//				case USER_PROP_ILLUMINANCE_VALUE_SOFT:
//					sum += 1;
//					break;
//				case USER_PROP_ILLUMINANCE_VALUE_MEDIUM:
//					sum += 2;
//					break;
//				case USER_PROP_ILLUMINANCE_VALUE_FULL:
//					sum += 3;
//					break;
//				default:
//					break;
//				}
//				System.out.println("");
//			}
//			preferedNumber = (int) sum / persons.size();
//			System.out.println("	preferedNumber -> " + preferedNumber
//					+ " (computeMaxBinaryIn)");
//			System.out.println("	sum -> " + sum);
//			System.out.println("	person.size() -> " + persons.size());
//		}
//		preferedNumber = Math.min(MaximumNumberOfLightsToTurnOn, preferedNumber);
		int preferedNumber = computeMaxIn(location);
		if (dimmerHandlers.length != 0) {
			DimmerLightsInterface dimmerHandler = dimmerHandlers[0];
			int dim = Math.min(dimmerHandler.getNumberOfDimmerLightIn(location), preferedNumber);
			return preferedNumber - dim;
		}
		return preferedNumber;
	}
	
	private int computeMaxDimmerIn(String location) {
		// Change here to modify power consumption
		// Change here to take dimmer light into account
//		System.out.println("Updating lights in " + location + " with :");
//		int preferedNumber = 0;
//		if (dimmerHandlers.length != 0) {
//			DimmerLightsInterface dimmerHandler = dimmerHandlers[0];
//			if (dimmerHandler.getNumberOfDimmerLightIn(location) > 0){
//				preferedNumber += 1;
//			}
//		}
//		return preferedNumber;
		
		int preferedNumber = computeMaxIn(location);
		if (dimmerHandlers.length != 0) {
			DimmerLightsInterface dimmerHandler = dimmerHandlers[0];
			int dim = Math.min(dimmerHandler.getNumberOfDimmerLightIn(location), preferedNumber);
			return dim;
		}
		return 0;
	}

	public int computeMaxBinaryIn(String location, int preferedNumberOfLight) {
		// Change here to modify power consumption
		// Change here to take dimmer light into account
		if (preferedNumberOfLight == -1) {
			return MaximumNumberOfLightsToTurnOn;
		} else {
			return Math.min(MaximumNumberOfLightsToTurnOn,
					preferedNumberOfLight);
		}
	}

	public int getUserPreference(String user) {
		String pref = (String) userPreferences.getUserPropertyValue(user,
				USER_PROP_ILLUMINANCE);
		int prefValue = -1;

		if (pref == null) {
			return prefValue;
		}
		switch (pref) {
		case USER_PROP_ILLUMINANCE_VALUE_SOFT:
			prefValue = 1;
			break;
		case USER_PROP_ILLUMINANCE_VALUE_MEDIUM:
			prefValue = 2;
			break;
		case USER_PROP_ILLUMINANCE_VALUE_FULL:
			prefValue = 3;
			break;
		default:
			break;
		}

		return prefValue;
	}

	// -------------------------- DeviceListener ----------------------------
	@Override
	public void deviceAdded(GenericDevice arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deviceEvent(GenericDevice arg0, Object arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void devicePropertyAdded(GenericDevice arg0, String arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void devicePropertyModified(GenericDevice device,
			String propertyName, Object oldValue, Object newValue) {

		//based on that assumption we can cast the generic device without checking via instanceof

		if (device instanceof PresenceSensor) {
			PresenceSensor changingSensor = (PresenceSensor) device;
			// check the change is related to presence sensing
			if (propertyName
					.equals(PresenceSensor.PRESENCE_SENSOR_SENSED_PRESENCE)) {
				// get the location of the changing sensor:
				String detectorLocation = (String) changingSensor
						.getPropertyValue(LOCATION_PROPERTY_NAME);

				System.out.println("The detector ("
						+ changingSensor.getSerialNumber() + ") in the "
						+ detectorLocation + "has changed");

				if (binaryHandlers.length == 0) {
					System.out.println("No handler for binary lights !");
				} else {
					System.out.println("Handling binary lights...");
					BinaryLightsInterface binaryHandler = binaryHandlers[0];
					if (changingSensor.getSensedPresence()) {
						binaryHandler.newRoom(detectorLocation,
								computeMaxBinaryIn(detectorLocation));
						binaryHandler.turnOnBinaryLightIn(detectorLocation,
								computeMaxBinaryIn(detectorLocation));
					} else {
						binaryHandler.turnOffBinaryLightIn(detectorLocation);
						binaryHandler.removeRoom(detectorLocation);
					}
				}
				
				if (dimmerHandlers.length == 0) {
					System.out.println("No handler for dimmer lights !");
				} else {
					System.out.println("Handling dimmer lights...");
					DimmerLightsInterface dimmerHandler = dimmerHandlers[0];
					if (changingSensor.getSensedPresence()) {
						dimmerHandler.newRoom(detectorLocation,
								computeMaxDimmerIn(detectorLocation));
						dimmerHandler.turnOnDimmerLightIn(detectorLocation,
								computeMaxDimmerIn(detectorLocation));
					} else {
						dimmerHandler.turnOffDimmerLightIn(detectorLocation);
						dimmerHandler.removeRoom(detectorLocation);
					}
				}
			}
		}
	}

	@Override
	public void devicePropertyRemoved(GenericDevice arg0, String arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deviceRemoved(GenericDevice arg0) {
		// TODO Auto-generated method stub

	}

	// -------------------------- DeviceListener ----------------------------

	/** Bind Method for binaryHandlers dependency */
	public void bindBinaryHandler(BinaryLightsInterface binaryLightsInterface,
			Map properties) {
		// TODO: Add your implementation code here
	}

	/** Unbind Method for binaryHandlers dependency */
	public void unbindBinaryHandler(
			BinaryLightsInterface binaryLightsInterface, Map properties) {
		// TODO: Add your implementation code here
	}

	// -------------------------- FollowMeConfiguration ----------------------------
	@Override
	public int getMaximumNumberOfLightsToTurnOn() {
		return MaximumNumberOfLightsToTurnOn;
	}

	@Override
	public void setMaximumNumberOfLightsToTurnOn(
			int maximumNumberOfLightsToTurnOn) {
		this.MaximumNumberOfLightsToTurnOn = maximumNumberOfLightsToTurnOn;

		if (binaryHandlers.length == 0) {
			System.out
					.println("No handler for binary lights ! Cannot update the lights");
		} else {
			System.out.println("Handling binary lights...");
			BinaryLightsInterface binaryHandler = binaryHandlers[0];
			Set<String> locationSet = binaryHandler.getOccupiedRomms();
			Iterator anIterator = locationSet.iterator();
			while (anIterator.hasNext()) {
				String location = (String) anIterator.next();
				int newNumber = computeMaxBinaryIn(location);
				binaryHandler.updateRoom(location, newNumber);
				binaryHandler.turnOnBinaryLightIn(location, newNumber);
			}
		}
		
		if (dimmerHandlers.length == 0) {
			System.out
					.println("No handler for dimmer lights ! Cannot update the lights");
		} else {
			System.out.println("Handling dimmer lights...");
			DimmerLightsInterface dimmerHandler = dimmerHandlers[0];
			Set<String> locationSet = dimmerHandler.getOccupiedRomms();
			Iterator anIterator = locationSet.iterator();
			while (anIterator.hasNext()) {
				String location = (String) anIterator.next();
				int newNumber = computeMaxDimmerIn(location);
				dimmerHandler.updateRoom(location, newNumber);
				dimmerHandler.turnOnDimmerLightIn(location, newNumber);
			}
		}
	}

	@Override
	public void updateRoom(String location, int preferedNumberOfLight) {
		if (binaryHandlers.length == 0) {
			System.out
					.println("No handler for binary lights ! Cannot update the lights");
		} else {
			System.out.println("Handling binary lights...");
			BinaryLightsInterface binaryHandler = binaryHandlers[0];
			int newNumber = computeMaxBinaryIn(location);
			binaryHandler.updateRoom(location, newNumber);
			binaryHandler.turnOnBinaryLightIn(location, newNumber);
		}
		
		if (dimmerHandlers.length == 0) {
			System.out
					.println("No handler for dimmer lights ! Cannot update the lights");
		} else {
			System.out.println("Handling dimmer lights...");
			DimmerLightsInterface dimmerHandler = dimmerHandlers[0];
			int newNumber = computeMaxDimmerIn(location);
			dimmerHandler.updateRoom(location, newNumber);
			dimmerHandler.turnOnDimmerLightIn(location, newNumber);
		}
	}

	// -------------------------- PeriodicRunnable ----------------------------
	@Override
	public synchronized void run() {
		System.out.println("run");
		if (binaryHandlers.length != 0) {
			BinaryLightsInterface binaryHandler = binaryHandlers[0];
			Set<String> rooms = binaryHandler.getOccupiedRomms();
			if (!rooms.isEmpty()) {
				Iterator anIterator = rooms.iterator();
				while (anIterator.hasNext()) {
					String location = (String) anIterator.next();
					int newNumber = computeMaxBinaryIn(location);
					binaryHandler.updateRoom(location, newNumber);
					binaryHandler.turnOnBinaryLightIn(location, newNumber);
				}
			}
		}
	}

	@Override
	public long getPeriod() {
		return 1;
	}

	@Override
	public TimeUnit getUnit() {
		return TimeUnit.HOURS;
	}

	// -------------------------- PreferenceChangeListener ----------------------------
	@Override
	public void changedProperty(String name, Object arg1, Object arg2) {
		String pref = (String) userPreferences.getUserPropertyValue(name, USER_PROP_ILLUMINANCE);
		System.out.println("The preferences of  " + name + " has changed with "+ pref +" (follow)");
		
		Set<String> locationsBinnary = null;
		Set<String> locationsDimmer = null;
		Set<String> locations = null;
		if (binaryHandlers.length != 0) {
			BinaryLightsInterface binaryHandler = binaryHandlers[0];
			locationsBinnary = binaryHandler.getOccupiedRomms();
		}
		if (dimmerHandlers.length != 0) {
			DimmerLightsInterface dimmerHandler = dimmerHandlers[0];
			locationsDimmer = dimmerHandler.getOccupiedRomms();
		}
		if (locationsBinnary != null){
			System.out.println("	bin : " + locationsBinnary.toString());
		}
		if (locationsDimmer != null){
			System.out.println("	dim : " + locationsDimmer.toString());
		}
		if (locationsBinnary == null || !locationsBinnary.isEmpty()){
			locations = locationsDimmer;
		} else if (locationsDimmer == null || !locationsDimmer.isEmpty()){
			locations = locationsBinnary;
		} else {
			locationsBinnary.addAll(locationsDimmer);
			locations =  locationsBinnary;
		}
		Set<String> rooms = locations;
		if (!rooms.isEmpty()) {
			Iterator anIterator = rooms.iterator();
			while (anIterator.hasNext()) {
				String location = (String) anIterator.next();
				if (binaryHandlers.length != 0) {
					BinaryLightsInterface binaryHandler = binaryHandlers[0];
					int newNumber = computeMaxBinaryIn(location);
					binaryHandler.updateRoom(location, newNumber);
					binaryHandler.turnOnBinaryLightIn(location, newNumber);
				}
				if (dimmerHandlers.length != 0) {
					DimmerLightsInterface dimmerHandler = dimmerHandlers[0];
					int newNumber = computeMaxDimmerIn(location);
					dimmerHandler.updateRoom(location, newNumber);
					dimmerHandler.turnOnDimmerLightIn(location, newNumber);
				}
				
			}
		}
	}

}
