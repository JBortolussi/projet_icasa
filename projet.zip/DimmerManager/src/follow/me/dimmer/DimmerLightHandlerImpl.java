package follow.me.dimmer;

import fr.liglab.adele.icasa.device.DeviceListener;
import fr.liglab.adele.icasa.device.GenericDevice;
import fr.liglab.adele.icasa.device.light.BinaryLight;
import fr.liglab.adele.icasa.device.light.DimmerLight;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DimmerLightHandlerImpl implements DimmerLightsInterface, DeviceListener {
	
	
	/**
     * The name of the LOCATION property
     */
    public static final String LOCATION_PROPERTY_NAME = "Location";
     
    /**
     * The name of the location for unknown value
     */
    public static final String LOCATION_UNKNOWN = "unknown";
	
	/** Field for dimmerLights dependency */
	private DimmerLight[] dimmerLights;
	
	// ------------------------------ Parameters ----------------------------------------
	private Hashtable<String, Integer>  occupiedRooms;
	
	// ------------------------------ Life cycle ----------------------------------------
	/** Bind Method for dimmerLights dependency */
	public void bindDimmerLights(DimmerLight dimmerLight, Map properties) {
		System.out.println("bind dimmer light " + dimmerLight.getSerialNumber());
		dimmerLight.addListener(this);
	}

	/** Unbind Method for dimmerLights dependency */
	public void unbindDimmerLights(DimmerLight dimmerLight, Map properties) {
		System.out.println("unbind dimmer light " + dimmerLight.getSerialNumber());
		dimmerLight.removeListener(this);
	}

	/** Component Lifecycle Method */
	public void stop() {
		System.out.println("BinaryLightHandler is stopping...");
		for (DimmerLight light : dimmerLights){
			light.removeListener(this);
		}
	}

	/** Component Lifecycle Method */
	public void start() {
		occupiedRooms = new Hashtable<String, Integer>();
		System.out.println("DimmerLightHandler is starting...");
	}
	
	// -------------------------------- Utility -----------------------------------------
	private synchronized List<DimmerLight> getDimmerLightFromLocation(
		    String location) {
		  List<DimmerLight> dimmerLightsLocation = new ArrayList<DimmerLight>();
		  for (DimmerLight dimLight : dimmerLights) {
		    if (dimLight.getPropertyValue(LOCATION_PROPERTY_NAME).equals(
		        location)) {
		    	dimmerLightsLocation.add(dimLight);
		    }
		  }
		  return dimmerLightsLocation;
		}
	
	// -------------------------- DimmerLightsInterface ---------------------------------
	@Override
	public void turnOnDimmerLightIn(String location, int maxNumber) {
		System.out.print("Updating dimmer lights in " + location + ", max number : " + maxNumber);
		List<DimmerLight> lights = getDimmerLightFromLocation(location);
		int numberOfLightOn = 0; 
		for (DimmerLight light : lights){
			if (numberOfLightOn < maxNumber){
				light.setPowerLevel(1.0);
				numberOfLightOn += 1;
			} else {
				light.setPowerLevel(0.0);
			}
			
		}
	}

	@Override
	public void turnOffDimmerLightIn(String location) {
		List<DimmerLight> lights = getDimmerLightFromLocation(location);
		for (DimmerLight light : lights){
			light.setPowerLevel(0.0);
		}
	}

	@Override
	public void newRoom(String name, int numberOfLightToBeOn) {
		occupiedRooms.put(name, new Integer(numberOfLightToBeOn));
	}

	@Override
	public void updateRoom(String name, int numberOfLightToBeOn) {
		occupiedRooms.replace(name, numberOfLightToBeOn);
	}

	@Override
	public int getRoom(String name) {
		Integer maxNumber = occupiedRooms.get(name);
		if (maxNumber == null){
			return -1;
		} else {
			return maxNumber.intValue();
		}
	}

	@Override
	public Set<String> getOccupiedRomms() {
		return occupiedRooms.keySet();
	}

	@Override
	public void removeRoom(String name) {
		occupiedRooms.remove(name);
	}
	
	@Override
	public int getNumberOfDimmerLightIn(String location) {
		List<DimmerLight> lights = getDimmerLightFromLocation(location);
		return lights.size();
	}
	
	// ----------------------------- DeviceListener -------------------------------------
	@Override
	public void deviceAdded(GenericDevice arg0) {}

	@Override
	public void deviceEvent(GenericDevice arg0, Object arg1) {}

	@Override
	public void devicePropertyAdded(GenericDevice arg0, String arg1) {}

	@Override
	public void devicePropertyModified(GenericDevice device, String propertyName,
			Object oldValue, Object arg3) {
		if (device instanceof DimmerLight) {
			DimmerLight changingLight = (DimmerLight) device;
			// check the change is related to presence sensing
			if (propertyName
					.equals(BinaryLight.LOCATION_PROPERTY_NAME)) {
				// get the location of the changing sensor:
				String lightLocation = (String) changingLight
						.getPropertyValue(LOCATION_PROPERTY_NAME);

				System.out.println("The light ("
						+ changingLight.getSerialNumber() + ") in the "
						+ lightLocation + " has moved");
				
				String oldLocation = (String) oldValue;
				
				// update new location
				int numberOfLightOn = 0;
				int maxlight = 0;
				List<DimmerLight> lights = null;
				if (occupiedRooms.containsKey(lightLocation)){
					maxlight = occupiedRooms.get(lightLocation);
					lights = getDimmerLightFromLocation(lightLocation);
					for (DimmerLight light : lights){
						if (light.getPowerLevel() > 0){
							numberOfLightOn += 1;
						}
					}
					if ( numberOfLightOn > maxlight){
						changingLight.setPowerLevel(0.0);
					} else if (numberOfLightOn < maxlight){
						changingLight.setPowerLevel(1.0);
					}
					
				} else {
					changingLight.setPowerLevel(0.0);
				}
				
				// update old location
				if (occupiedRooms.containsKey(oldLocation)){
					numberOfLightOn = 0;
					maxlight = occupiedRooms.get(oldLocation);
					lights = getDimmerLightFromLocation(oldLocation);
					for (DimmerLight light : lights){
						if (light.getPowerLevel() > 0){
							numberOfLightOn += 1;
						}
					}
					for (DimmerLight light : lights){
						if ((light.getPowerLevel() <= 0) && numberOfLightOn < maxlight){
							numberOfLightOn += 1;
							light.setPowerLevel(1.0);
						}
					}
				}
			}
		}
	}

	@Override
	public void devicePropertyRemoved(GenericDevice arg0, String arg1) {}

	@Override
	public void deviceRemoved(GenericDevice arg0) {}
}
