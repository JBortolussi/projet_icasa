package follow.me.dimmer;

import java.util.Set;

public interface DimmerLightsInterface {
	public void turnOnDimmerLightIn(String location, int maxNumber);
	public void turnOffDimmerLightIn(String location);
	public void newRoom(String name, int numberOfLightToBeOn);
	public void updateRoom(String name, int numberOfLightToBeOn);
	public int  getRoom(String name);
	public Set<String> getOccupiedRomms();
	public void removeRoom(String name);
	
	public int getNumberOfDimmerLightIn(String location);
}
